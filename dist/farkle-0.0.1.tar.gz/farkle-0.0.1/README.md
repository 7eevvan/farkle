# Example Package

Package to simulate the farkle dice game, based on the rules from [RNK Gaming.](https://rnkgaming.com/farkle-rules-2)